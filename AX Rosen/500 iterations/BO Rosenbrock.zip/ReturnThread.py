from threading import Thread

# custom thread
class ReturnThread(Thread):
    # constructor
    def __init__(self, target, args):
        # execute the base constructor
        super().__init__(group=None, target=target, args=args)
        # set a default value
        self.value = None
    # function executed in a new thread
    def run(self):
        self.value = self._target(self._args)